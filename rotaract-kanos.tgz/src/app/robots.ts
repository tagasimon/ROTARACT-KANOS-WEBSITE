import type { MetadataRoute } from "next";
import { absoluteUrl } from "@/lib/utils";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/account", "/check-in", "/api/", "/login"] }],
    sitemap: absoluteUrl("/sitemap.xml"),
  };
}
